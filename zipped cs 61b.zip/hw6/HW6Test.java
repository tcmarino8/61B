/** Tests of HW5
 *  @author P. N. Hilfinger
 */
public class HW6Test {

    public static void main(String[] args) {
        System.exit(ucb.junit.textui.runClasses(BSTStringSetTest.class,
                                                BSTStringSetRangeTest.class,
                                                ECHashStringSetTest.class));
    }

}

