import java.util.Objects;

/**
 * TableFilter to filter for entries whose two columns match.
 *
 * @author Matthew Owen
 */
public class ColumnMatchFilter extends TableFilter {

    public ColumnMatchFilter(Table input, String colName1, String colName2) {
        super(input);
        col1 = input.colNameToIndex(colName1);
        col2 = input.colNameToIndex(colName2);


    }

    @Override
    protected boolean keep() {
        if (Objects.equals(candidateNext().getValue(col1), candidateNext().getValue(col2))){
            return true;
        }
        return false;
    }
    public int col1;
    public int col2;

}
