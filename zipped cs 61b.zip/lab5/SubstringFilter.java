/**
 * TableFilter to filter for containing substrings.
 *
 * @author Matthew Owen
 */
public class SubstringFilter extends TableFilter {
    public int _col;
    public String inside;

    public SubstringFilter(Table input, String colName, String subStr) {
        super(input);
        _col = input.colNameToIndex(colName);
        inside = subStr;
    }

    @Override
    protected boolean keep() {
        if( candidateNext().getValue(_col).contains(inside)){
            return true;
        }
        return false;
    }

    // FIXME: Add instance variables?
}
