/**
 * TableFilter to filter for entries greater than a given string.
 *
 * @author Matthew Owen
 */
public class GreaterThanFilter extends TableFilter {
    public String _ref;
    public int col;

    public GreaterThanFilter(Table input, String colName, String ref) {
        super(input);
        _ref = ref;
        col = input.colNameToIndex(colName);


    }

    @Override
    protected boolean keep() {
        if (candidateNext().getValue(col).compareTo(_ref) > 0){
            return true;
        }
        return false;
    }

}
