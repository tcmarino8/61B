/**
 * TableFilter to filter for entries equal to a given string.
 *
 * @author Matthew Owen
 */
public class EqualityFilter extends TableFilter {

    public EqualityFilter(Table input, String colName, String match) {
        super(input);
        goal = match;
        given = input.colNameToIndex(colName);

    }

    @Override
    protected boolean keep() {
        if(candidateNext().getValue(given).equals(goal)){
            return true;
        }
        return false;
    }
    public int given;
    public String goal;

}
