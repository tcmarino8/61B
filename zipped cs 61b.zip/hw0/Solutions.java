/** Solutions to the HW0 Java101 exercises.
 *  @author Allyson Park and [INSERT YOUR NAME HERE]
 */
public class Solutions {

    /**
     * Returns whether or not the input x is even.
     */
    public static boolean isEven(int x) {
        if ((x == 0) || ( x % 2 == 0)) {
            return true;
        }
        return false;
    }

    public static int max(int[] a) {
        assert(a.length > 0);
        int value = a[0];
        for(int i=1; i < a.length; i++) {
            if (a[i] > value) {
                value = a[i];
            }
        }
        return value;


            }
    public static boolean wordBank(String word, String[] bank) {
        for (String element : bank) {
            if (element.equals(word))
                return true;
        }
        return false;
    }




    public static boolean threeSum(int[] a) {
        for (int i = 0; i < a.length-2; i++) {
            for (int k = 0; k < a.length-1; k++){
                for (int j = 0; j < a.length; j++){
                    if (a[i] + a[k] + a[j] == 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }


    // TODO: Fill in the method signatures for the other exercises
    // Your methods should be static for this HW. DO NOT worry about what this means.
    // Note that "static" is not necessarily a default, it just happens to be what
    // we want for THIS homework. In the future, do not assume all methods should be
    // static.

}
