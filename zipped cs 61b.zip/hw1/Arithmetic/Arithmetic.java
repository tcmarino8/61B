/** A couple of arithmetic functions.
 *  @author
 */
public class Arithmetic {

    /** Returns the product of A and B. */
    public static double product(double a, double b) {
        return a * b;
    }

    /** Returns the sum of A and B. */
    public static double sum(double a, double b) {
        return a + b; // WRONG
    }
}
